/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'tt', {
	alt: 'Альтернатив текст',
	btnUpload: 'Серверга җибәрү',
	captioned: 'Исеме куелган рәсем',
	captionPlaceholder: 'Исем',
	infoTab: 'Рәсем тасвирламасы',
	lockRatio: 'Lock Ratio', // MISSING
	menu: 'Рәсем үзлекләре',
	pathName: 'рәсем',
	pathNameCaption: 'исем',
	resetSize: 'Баштагы зурлык',
	resizer: 'Күчереп куер өчен басып шудырыгыз',
	title: 'Рәсем үзлекләре',
	uploadTab: 'Йөкләү',
	urlMissing: 'Image source URL is missing.', // MISSING
	altMissing: 'Alternative text is missing.' // MISSING
} );
